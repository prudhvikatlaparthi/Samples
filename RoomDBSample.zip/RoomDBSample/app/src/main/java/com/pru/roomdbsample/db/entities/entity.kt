package com.pru.roomdbsample.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "basic_details")
data class BasicDetailsEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val reportId: Long
)

@Entity(tableName = "layout")
data class LayoutEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val mergeWithAboveLayout: Int,
    val sortOrder: Int,
    val basicDetailsId: Long
)

@Entity(tableName = "control")
data class ControlEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val numberOfColumns: Int,
    val value: String,
    val hint: String,
    val inputType: String,
    val inputData: String?,
    val dataType: String,
    val colour: String,
    val isInfoIcon: Int,
    val infoText: String,
    val layoutId: Long
)