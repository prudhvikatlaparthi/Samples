package com.pru.responsiveapp.ui.alpha

import androidx.lifecycle.ViewModel

abstract class BaseViewModel : ViewModel() {

    fun doSomething() {

    }

    override fun onCleared() {
        super.onCleared()
    }
}