package com.pru.responsiveapp.data.models

data class MyMenuItem(
    var title: Int,
    var imgResource: Int
)
