package com.pru.responsiveapp.ui.alpha

import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.pru.responsiveapp.R
import com.pru.responsiveapp.databinding.FragmentDetailBinding
import com.pru.responsiveapp.popFragment
import com.pru.responsiveapp.ui.base.BaseFragment


class DetailFragment : BaseFragment(R.layout.fragment_detail) {
    private lateinit var fragmentDetailBinding: FragmentDetailBinding
    private lateinit var ldViewModel: LDViewModel
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fragmentDetailBinding = FragmentDetailBinding.bind(view)
        ldViewModel = ViewModelProvider(requireParentFragment()).get(LDViewModel::class.java)
        if (!ldViewModel.isLandScape) {
            setupToolbar(showBackButton = true)
        } else {
            parentFragmentManager.popFragment()
        }
        ldViewModel.number.observe(viewLifecycleOwner) {
            if (it > -1) {
                ldViewModel.obxData.value?.get(it)?.apply {
                    setupToolbarTitle(title)
                    fragmentDetailBinding.numbTxt.text = title + "\n" + description
                }
            }
        }
    }
}