package com.pru.responsiveapp.ui.alpha

import android.os.Bundle
import android.view.View
import androidx.navigation.fragment.findNavController
import com.pru.responsiveapp.R
import com.pru.responsiveapp.databinding.FragmentDummyBinding
import com.pru.responsiveapp.ui.base.BaseFragment

class DummyFragment : BaseFragment(R.layout.fragment_dummy) {
    private lateinit var fragmentDummyBinding: FragmentDummyBinding
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupToolbar("Dummy")
        fragmentDummyBinding = FragmentDummyBinding.bind(view)
        fragmentDummyBinding.tap.setOnClickListener {
            findNavController().navigate(R.id.action_dummyFragment_to_listDetailFragment)
        }
    }
}