package com.pru.responsiveapp.listeners

interface BackPressListener {
    fun onBackPress(refresh: Boolean)
}