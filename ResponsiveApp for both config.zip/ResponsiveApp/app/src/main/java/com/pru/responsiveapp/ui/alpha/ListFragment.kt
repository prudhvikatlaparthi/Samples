package com.pru.responsiveapp.ui.alpha

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import com.pru.responsiveapp.R
import com.pru.responsiveapp.databinding.FragmentListBinding
import com.pru.responsiveapp.popFragment
import com.pru.responsiveapp.replaceFragment
import com.pru.responsiveapp.standardMenuList
import com.pru.responsiveapp.ui.base.BaseFragment
import java.util.*


class ListFragment : BaseFragment(R.layout.fragment_list) {
    private lateinit var fragmentListBinding: FragmentListBinding
    private val dashBoardListAdapter by lazy { DashBoardListAdapter(::listItemClickListener) }
    private lateinit var ldViewModel: LDViewModel

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fragmentListBinding = FragmentListBinding.bind(view)
        ldViewModel = ViewModelProvider(requireParentFragment()).get(LDViewModel::class.java)
        fragmentListBinding.rcView.adapter = dashBoardListAdapter
        val smoothScroller: RecyclerView.SmoothScroller =
            object : LinearSmoothScroller(requireContext()) {
                override fun getVerticalSnapPreference(): Int {
                    return SNAP_TO_START
                }
            }
        ldViewModel.obxData.observe(viewLifecycleOwner, {
            dashBoardListAdapter.submitList(it)
            ldViewModel.number.value = ldViewModel.number.value
            fragmentListBinding.pbView.isVisible = false
            if (ldViewModel.isNewDataAdded) {
                ldViewModel.isNewDataAdded = false
                Handler(Looper.getMainLooper()).postDelayed({
                    smoothScroller.targetPosition = 0
                    fragmentListBinding.rcView.layoutManager?.startSmoothScroll(
                        smoothScroller
                    )
                }, 500)
            }
        })
        prepareToolbar()
    }

    fun prepareToolbar() {
        setupToolbar(
            title = "Fruits",
            showBackButton = true,
            isRequiredOptionMenu = true,
            menuItemClickCallBack = ::menuOptionsCallback,
            menuList = standardMenuList
        )
    }

    private fun menuOptionsCallback(itemName: String) {
        Toast.makeText(requireContext(), itemName, Toast.LENGTH_SHORT).show()
        when (itemName.toLowerCase(Locale.getDefault())) {
            "search" -> {
                findNavController().navigate(R.id.action_global_searchFragment)
            }
            "add" -> {
                if (ldViewModel.isLandScape) {
                    parentFragmentManager.replaceFragment(
                        isAnimationRequired = true, fragment = CreateFragment(),
                        containerID = R.id.detailContainer
                    )
                } else {
                    parentFragmentManager.replaceFragment(
                        isAnimationRequired = true, fragment = CreateFragment(),
                        containerID = R.id.listContainer
                    )
                }
            }
            else -> Unit
        }
    }

    private fun listItemClickListener(position: Int) {
        ldViewModel.number.value = position
        if (!ldViewModel.isLandScape) {
            parentFragmentManager.replaceFragment(
                isAnimationRequired = true, fragment = DetailFragment(),
                containerID = R.id.listContainer
            )
        } else {
            parentFragmentManager.popFragment()
        }
    }
}