package com.pru.responsiveapp.ui.alpha

import android.os.Bundle
import android.view.View
import com.pru.responsiveapp.R
import com.pru.responsiveapp.ui.base.BaseFragment

class SearchFragment : BaseFragment(R.layout.fragment_search) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupToolbar(title = "Search", showBackButton = true)
    }
}