package com.pru.responsiveapp.listeners

import com.pru.responsiveapp.data.models.DataItem

interface DualPaneItemListener {
    fun onItemClickListener(dataItem: DataItem)
}