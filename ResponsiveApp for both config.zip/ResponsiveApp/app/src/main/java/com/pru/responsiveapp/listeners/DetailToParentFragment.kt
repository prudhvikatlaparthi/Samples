package com.pru.responsiveapp.listeners

import com.pru.responsiveapp.data.models.DataItem

interface DetailToParentFragment {
    fun openCreate(dataItem: DataItem?)
}