package com.pru.responsiveapp.listeners

interface ListToParentFragmentListener {

}