package com.pru.responsiveapp.ui.alpha

import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.pru.responsiveapp.R
import com.pru.responsiveapp.databinding.FragmentListDetailBinding
import com.pru.responsiveapp.popFragment
import com.pru.responsiveapp.replaceFragment
import com.pru.responsiveapp.ui.base.BaseFragment


class ListDetailFragment : BaseFragment(R.layout.fragment_list_detail) {
    lateinit var fragmentListDetailBinding: FragmentListDetailBinding
    private lateinit var ldViewModel: LDViewModel
    private lateinit var listFragment: ListFragment
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        fragmentListDetailBinding = FragmentListDetailBinding.bind(view)
        ldViewModel = ViewModelProvider(this).get(LDViewModel::class.java)
        listFragment = ListFragment()
        setupToolbarTitle(name = "Fruits")
        if (fragmentListDetailBinding.detailContainer != null) {
            ldViewModel.isLandScape = true
            childFragmentManager.popFragment()
            childFragmentManager.replaceFragment(
                fragment = listFragment,
                containerID = fragmentListDetailBinding.listContainer.id
            )
            childFragmentManager.replaceFragment(
                fragment = DetailFragment(),
                containerID = fragmentListDetailBinding.detailContainer!!.id
            )
        } else {
            ldViewModel.isLandScape = false
            childFragmentManager.replaceFragment(
                fragment = listFragment,
                containerID = fragmentListDetailBinding.listContainer.id
            )
        }
        childFragmentManager.addOnBackStackChangedListener {
            if (childFragmentManager.fragments.size > 0) {
                var fragment =
                    childFragmentManager.fragments[childFragmentManager.fragments.size - 1]
                if (fragment is DetailFragment && ldViewModel.isLandScape) {
                    fragment = childFragmentManager.fragments[0]
                }
                if (fragment is ListFragment) {
                    fragment.prepareToolbar()
                }
            }
        }
    }


}