package com.pru.responsiveapp.customviews

import android.content.Context
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import com.pru.responsiveapp.data.models.MyMenuItem
import com.pru.responsiveapp.databinding.MenuViewBinding

class MenuView(context: Context, myMenuItem: MyMenuItem, callBack: (String) -> Unit) :
    LinearLayout(context) {

    init {
        val menuViewBinding = MenuViewBinding.inflate(LayoutInflater.from(context), this, true)
        menuViewBinding.imgMenu.setImageDrawable(
            ContextCompat.getDrawable(
                context,
                myMenuItem.imgResource
            )
        )
        menuViewBinding.imgMenu.contentDescription = context.getString(myMenuItem.title)
        menuViewBinding.root.setOnClickListener {
            callBack.invoke(context.getString(myMenuItem.title))
        }
    }
}