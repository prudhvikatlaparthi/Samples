package com.shopping.jewellery.entity;

import com.shopping.jewellery.utils.OrderStatus;
import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "order_tbl")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    private LocalDateTime date;

    @Enumerated(EnumType.STRING)
    @Column(name="status")
    private OrderStatus status;

    @OneToOne
    private Cart cart;

    public Order() {
    }

    public Order(int orderId, LocalDateTime date, OrderStatus status, Cart cart) {
        this.orderId = orderId;
        this.date = date;
        this.status = status;
        this.cart = cart;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }
}