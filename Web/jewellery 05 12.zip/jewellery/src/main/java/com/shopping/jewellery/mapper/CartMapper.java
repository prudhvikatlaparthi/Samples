package com.shopping.jewellery.mapper;

import com.shopping.jewellery.dto.CartDTO;
import com.shopping.jewellery.dto.ProductDTO;
import com.shopping.jewellery.entity.Cart;
import com.shopping.jewellery.entity.Product;

public class CartMapper {

    public static CartDTO mapToDTO(Cart item) {
        if (item == null) return null;
        return new CartDTO(item.getCartId(),UserMapper.mapToDTO(item.getUser()),item.getProducts().stream().map(ProductMapper::mapToDTO).toList(),item.getCartItemQuantity(), item.getCartTotalPrice());
    }

    public static Cart mapTo(CartDTO dto) {
        if (dto == null) return null;
        return new Cart(dto.getCartId(),UserMapper.mapTo(dto.getUser()),dto.getProducts().stream().map(ProductMapper::mapTo).toList(),dto.getCartItemQuantity(),dto.getCartTotalPrice());
    }
}