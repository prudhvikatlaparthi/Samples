package com.shopping.jewellery.mapper;

import com.shopping.jewellery.dto.OrderDTO;
import com.shopping.jewellery.entity.Order;

public class OrderMapper {

    public static OrderDTO mapToDTO(Order item) {
        if (item == null) return null;
        return new OrderDTO(item.getOrderId(), item.getDate(), item.getStatus(), CartMapper.mapToDTO(item.getCart()));
    }

    public static Order mapTo(OrderDTO dto) {
        if (dto == null) return null;
        return new Order(dto.getOrderId(), dto.getDate(), dto.getStatus(), CartMapper.mapTo(dto.getCart()));
    }
}