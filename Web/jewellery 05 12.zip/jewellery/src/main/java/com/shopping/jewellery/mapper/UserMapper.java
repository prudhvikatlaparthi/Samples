package com.shopping.jewellery.mapper;

import com.shopping.jewellery.dto.UserDTO;
import com.shopping.jewellery.entity.User;

public class UserMapper {

    public static UserDTO mapToDTO(User item) {
        if (item == null) return null;
        return new UserDTO(item.getUserId(), item.getUserName(), item.getPassword(), item.getRole(), item.getFirstName(), item.getLastName(), item.getAddress(), item.getMobileNumber(), item.getPanCardNo(), CartMapper.mapToDTO(item.getCart()));
    }

    public static User mapTo(UserDTO dto) {
        if (dto == null) return null;
        return new User(dto.getUserId(), dto.getUserName(), dto.getPassword(), dto.getRole(), dto.getFirstName(), dto.getLastName(), dto.getAddress(), dto.getMobileNumber(), dto.getPanCardNo(), CartMapper.mapTo(dto.getCart()));
    }
}