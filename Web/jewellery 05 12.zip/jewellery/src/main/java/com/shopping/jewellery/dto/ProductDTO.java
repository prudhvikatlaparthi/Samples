package com.shopping.jewellery.dto;

import java.util.ArrayList;
import java.util.List;

public class ProductDTO {

    private int productId;
    private String productName;
    private CategoryDTO category;
    private int quantity;
    private double price;
    private String productImage;

    private List<CartDTO> cart =  new ArrayList<>();

    public ProductDTO() {
    }

    public ProductDTO(int productId, String productName, CategoryDTO category, int quantity, double price, String productImage, List<CartDTO> cart) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.quantity = quantity;
        this.price = price;
        this.productImage = productImage;
        this.cart = cart;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public CategoryDTO getCategory() {
        return category;
    }

    public void setCategory(CategoryDTO category) {
        this.category = category;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }

    public List<CartDTO> getCart() {
        return cart;
    }

    public void setCart(List<CartDTO> cart) {
        this.cart = cart;
    }
}
