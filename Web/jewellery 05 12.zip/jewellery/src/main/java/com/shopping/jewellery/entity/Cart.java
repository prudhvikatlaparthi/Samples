package com.shopping.jewellery.entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cart_tbl")
public class Cart {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int cartId;

    @OneToOne
    private User user;

    @ManyToMany()
    private List<Product> products = new ArrayList<>();

    private int cartItemQuantity;
    private double cartTotalPrice;

    public Cart() {
    }

    public Cart(int cartId, User user, List<Product> products, int cartItemQuantity, double cartTotalPrice) {
        this.cartId = cartId;
        this.user = user;
        this.products = products;
        this.cartItemQuantity = cartItemQuantity;
        this.cartTotalPrice = cartTotalPrice;
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public int getCartItemQuantity() {
        return cartItemQuantity;
    }

    public void setCartItemQuantity(int cartItemQuantity) {
        this.cartItemQuantity = cartItemQuantity;
    }

    public double getCartTotalPrice() {
        return cartTotalPrice;
    }

    public void setCartTotalPrice(double cartTotalPrice) {
        this.cartTotalPrice = cartTotalPrice;
    }
}