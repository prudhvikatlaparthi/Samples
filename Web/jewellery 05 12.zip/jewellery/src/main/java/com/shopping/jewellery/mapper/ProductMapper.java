package com.shopping.jewellery.mapper;

import com.shopping.jewellery.dto.ProductDTO;
import com.shopping.jewellery.entity.Product;

public class ProductMapper {

    public static ProductDTO mapToDTO(Product item) {
        if (item == null) return null;
        return new ProductDTO(item.getProductId(), item.getProductName(), CategoryMapper.mapToDTO(item.getCategory()), item.getQuantity(), item.getPrice(), item.getProductImage(), item.getCart().stream().map(CartMapper::mapToDTO).toList());
    }

    public static Product mapTo(ProductDTO dto) {
        if (dto == null) return null;
        return new Product(dto.getProductId(), dto.getProductName(), CategoryMapper.mapTo(dto.getCategory()), dto.getCart().stream().map(CartMapper::mapTo).toList(), dto.getQuantity(), dto.getPrice(), dto.getProductImage());
    }
}