package com.shopping.jewellery.daoservice;


import com.shopping.jewellery.dto.CategoryDTO;
import com.shopping.jewellery.dto.ProductDTO;
import com.shopping.jewellery.mapper.CategoryMapper;
import com.shopping.jewellery.mapper.ProductMapper;
import com.shopping.jewellery.repository.ProductRepository;
import com.shopping.jewellery.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductDaoService implements ProductService {
    @Autowired
    private ProductRepository repository;

    public ProductDTO getById(int id) {
        return null;
    }

    public ProductDTO updateProduct(ProductDTO productDTO) {
        return null;
    }

    public boolean deleteProduct(ProductDTO productDTO) {
        return false;
    }

    public String addProduct(ProductDTO productDTO) {
        repository.save(ProductMapper.mapTo(productDTO));
        return "Product Added";
    }

    public List<ProductDTO> findAll() {
        return repository.findAll().stream().map(ProductMapper::mapToDTO).toList();
    }

    public List<ProductDTO> findAllByCategory(CategoryDTO categoryDTO) {
        return repository.findAllByCategory(CategoryMapper.mapTo(categoryDTO)).stream().map(ProductMapper::mapToDTO).toList();
    }

    public List<ProductDTO> getProductByCategoryName(int categoryName) {
        return null;
    }

}
