package com.shopping.jewellery.controller;

import com.shopping.jewellery.daoservice.CartDaoService;
import com.shopping.jewellery.dto.CartDTO;
import com.shopping.jewellery.dto.ProductDTO;
import com.shopping.jewellery.mapper.ProductMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("api/cart")
public class CartController {

    @Autowired
    private CartDaoService service;

    @PostMapping("/addToCart")
    public String addToCart(@RequestBody CartDTO cartDTO) {
        return service.addToCart(cartDTO);
    }

    @PostMapping("/deleteCartProduct")
    public String deleteCartProduct(@RequestBody ProductDTO productDTO) {
        return service.deleteProduct(productDTO);
    }

    @PostMapping("/getCartProducts")
    public List<ProductDTO> getCartProducts(@RequestBody CartDTO cartDTO) {
        return service.getCartProducts(cartDTO).stream().map(ProductMapper::mapToDTO).toList();
    }

}
