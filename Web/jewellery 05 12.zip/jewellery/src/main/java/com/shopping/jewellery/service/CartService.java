package com.shopping.jewellery.service;


import com.shopping.jewellery.dto.CartDTO;
import com.shopping.jewellery.dto.ProductDTO;

public interface CartService {
	
	//use throws for throwing appropriate Exceptions with functions
	public String addToCart(CartDTO cartDTO);

	public String deleteProduct(ProductDTO productDTO);
}
