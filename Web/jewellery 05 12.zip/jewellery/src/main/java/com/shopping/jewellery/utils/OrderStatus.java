package com.shopping.jewellery.utils;

public enum OrderStatus {
    Delivered,
    Inprogress,
    Cancelled
}