package com.shopping.jewellery.daoservice;


import com.shopping.jewellery.dto.CartDTO;
import com.shopping.jewellery.dto.ProductDTO;
import com.shopping.jewellery.entity.Cart;
import com.shopping.jewellery.entity.Product;
import com.shopping.jewellery.mapper.CartMapper;
import com.shopping.jewellery.mapper.ProductMapper;
import com.shopping.jewellery.repository.CartRepository;
import com.shopping.jewellery.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CartDaoService implements CartService {

    @Autowired
    private CartRepository repository;

    public String addToCart(CartDTO cartDTO) {
        repository.save(CartMapper.mapTo(cartDTO));
        return "Added to Cart";
    }

    public String deleteProduct(ProductDTO productDTO) {
        repository.deleteByProducts(ProductMapper.mapTo(productDTO));
        return "Deleted successfully";
    }

    public List<Product> getCartProducts(CartDTO cartDTO) {
        try {
            Cart allProductsByCartId = repository.findById(cartDTO.getCartId()).get();
            return allProductsByCartId.getProducts();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}
