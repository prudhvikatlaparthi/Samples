package com.shopping.jewellery.dto;

import com.shopping.jewellery.utils.OrderStatus;

import java.time.LocalDateTime;

public class OrderDTO {
	private int orderId;
	private LocalDateTime date;
	private OrderStatus status;
	private CartDTO cart;

	public OrderDTO() {
	}

	public OrderDTO(int orderId, LocalDateTime date, OrderStatus status, CartDTO cart) {
		this.orderId = orderId;
		this.date = date;
		this.status = status;
		this.cart = cart;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public OrderStatus getStatus() {
		return status;
	}

	public void setStatus(OrderStatus status) {
		this.status = status;
	}

	public CartDTO getCart() {
		return cart;
	}

	public void setCart(CartDTO cart) {
		this.cart = cart;
	}
}
