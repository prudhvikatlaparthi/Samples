package com.shopping.jewellery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JewelleryStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(JewelleryStoreApplication.class, args);
	}

}
