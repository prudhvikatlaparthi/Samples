package com.shopping.jewellery.daoservice;


import com.shopping.jewellery.dto.OrderDTO;
import com.shopping.jewellery.repository.OrderRepository;
import com.shopping.jewellery.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class OrderDaoService implements OrderService {
	//use throws for throwing appropriate Exceptions with functions

	@Autowired
	private OrderRepository repository;

	public OrderDTO addOrders(OrderDTO ordersDTO) {
		return null;
	}

	public OrderDTO updateOrders(OrderDTO ordersDTO) {
		return null;
	}

	public boolean deleteOrders(OrderDTO ordersDTO) {
		return false;
	}

	public OrderDTO getById(int id) {
		return null;
	}

	public List<OrderDTO> findAll() {
		return null;
	}

	public List<OrderDTO> getOrderCustomerId(int customerId) {
		return null;
	}

	public List<OrderDTO> getOrderCustomerEmail(int customerEmail) {
		return null;
	}

	public List<OrderDTO> getOrderByStatus(String orderstatus) {
		return null;
	}
}
