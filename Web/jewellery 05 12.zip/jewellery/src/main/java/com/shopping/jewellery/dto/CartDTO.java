package com.shopping.jewellery.dto;

import java.util.ArrayList;
import java.util.List;

public class CartDTO {

    private int cartId;
    private UserDTO user;
    private List<ProductDTO> products = new ArrayList<>();
    private int cartItemQuantity;
    private double cartTotalPrice;

    public CartDTO() {
    }

    public CartDTO(int cartId, UserDTO user, List<ProductDTO> products, int cartItemQuantity, double cartTotalPrice) {
        this.cartId = cartId;
        this.user = user;
        this.products = products;
        this.cartItemQuantity = cartItemQuantity;
        this.cartTotalPrice = cartTotalPrice;
    }

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public List<ProductDTO> getProducts() {
        return products;
    }

    public void setProducts(List<ProductDTO> products) {
        this.products = products;
    }

    public int getCartItemQuantity() {
        return cartItemQuantity;
    }

    public void setCartItemQuantity(int cartItemQuantity) {
        this.cartItemQuantity = cartItemQuantity;
    }

    public double getCartTotalPrice() {
        return cartTotalPrice;
    }

    public void setCartTotalPrice(double cartTotalPrice) {
        this.cartTotalPrice = cartTotalPrice;
    }
}
