package com.shopping.jewellery.mapper;

import com.shopping.jewellery.dto.CategoryDTO;
import com.shopping.jewellery.entity.Category;

public class CategoryMapper {

    public static CategoryDTO mapToDTO(Category item) {
        if (item == null) return null;
        return new CategoryDTO(item.getCategoryId(), item.getCategoryName());
    }

    public static Category mapTo(CategoryDTO dto) {
        if (dto == null) return null;
        return new Category(dto.getCategoryId(), dto.getCategoryName());
    }
}