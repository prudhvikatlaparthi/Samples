package com.shopping.jewellery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JewelleryStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
