package com.shopping.jewellery.utils;

public enum OrderStatus {

    Placed, InProgress, Delivered, Cancelled
}