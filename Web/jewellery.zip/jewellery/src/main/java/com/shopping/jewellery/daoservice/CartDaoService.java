package com.shopping.jewellery.daoservice;


import com.shopping.jewellery.dto.CartDTO;
import com.shopping.jewellery.dto.CartItemDTO;
import com.shopping.jewellery.dto.ProductDTO;
import com.shopping.jewellery.entity.Cart;
import com.shopping.jewellery.entity.CartItem;
import com.shopping.jewellery.entity.Product;
import com.shopping.jewellery.mapper.CartMapper;
import com.shopping.jewellery.mapper.ProductMapper;
import com.shopping.jewellery.repository.CartItemRepository;
import com.shopping.jewellery.repository.CartRepository;
import com.shopping.jewellery.repository.ProductRepository;
import com.shopping.jewellery.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class CartDaoService implements CartService {

    @Autowired
    private CartRepository repository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private CartMapper mapper;

    @Autowired
    private ProductMapper productMapper;

    public String addCartItem(CartDTO cartDTO) {
//        Cart activeCart = repository.findCartByIsActive(true);
        Cart entity = mapper.dtoToEntity(cartDTO);
        /*if (entity.getCartId() == 0){
            if (activeCart != null){
                activeCart.setActive(false);
                repository.save(activeCart);
            }
            entity.setActive(true);
        }*/
        Cart cart = repository.save(entity);
        cartDTO.getProductIds().forEach(p -> {
            CartItem cartItem = cartItemRepository.findCartItemByProductProductIdAndCartCartId(p, cartDTO.getCartId());
            if (cartItem != null) {
                cartItem.setQuantity(cartItem.getQuantity() + cartDTO.getQuantity());
                cartItemRepository.save(cartItem);
            } else {
                Product prod = productRepository.findById(p).get();
                CartItem newCart = new CartItem();
                newCart.setProduct(prod);
                newCart.setCart(cart);
                newCart.setQuantity(cartDTO.getQuantity());
                cartItemRepository.save(newCart);
            }
        });
        updateCart(cart.getCartId());
        return "Cart Item Added";
    }


    public String deleteCartItem(CartItemDTO cartDTO) {
        CartItem cartItem = cartItemRepository.findById(cartDTO.getId()).get();
        if (cartItem.getQuantity() == 1) {
            cartItemRepository.deleteById(cartItem.getId());
        } else {
            cartItem.setQuantity(cartItem.getQuantity() - cartDTO.getQuantity());
            cartItemRepository.save(cartItem);
        }
        updateCart(cartItem.getCart().getCartId());
        return "Cart Item Deleted";
    }

    public String updateCartItem(CartItemDTO cartDTO) {
        CartItem cartItem = cartItemRepository.findById(cartDTO.getId()).get();
        cartItem.setQuantity(cartItem.getQuantity() + cartDTO.getQuantity());
        cartItemRepository.save(cartItem);
        updateCart(cartItem.getCart().getCartId());
        return "Cart Item Updated";
    }

    private void updateCart(int cartId) {
        Cart cart = repository.findById(cartId).get();
        List<CartItem> cartItems = cartItemRepository.findAllCartItemsByCartCartId(cartId);
        AtomicInteger totalQuantity = new AtomicInteger();
        AtomicReference<Double> totalPrice = new AtomicReference<>((double) 0);
        cartItems.forEach(c -> {
            totalQuantity.set(totalQuantity.get() + c.getQuantity());
            totalPrice.set(totalPrice.get() + (c.getProduct().getPrice() * c.getQuantity()));

        });
        cart.setCartTotalPrice(totalPrice.get());
        cart.setCartItemQuantity(totalQuantity.get());
        repository.save(cart);
    }

    public List<ProductDTO> getCartProducts(int userId) {
        try {
            Cart cart = repository.findCartByUserUserId(userId);
            if (cart == null || cart.getCartId() == 0) return new ArrayList<>();
            List<CartItem> cartItems = cartItemRepository.findAllCartItemsByCartCartId(cart.getCartId());
            return cartItems.stream().map(p -> {
                ProductDTO pro = productMapper.entityToDto(p.getProduct());
                pro.setQuantity(p.getQuantity());
                pro.setPrice(p.getQuantity() * pro.getPrice());
                return pro;
            }).toList();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}
