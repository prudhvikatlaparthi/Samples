package com.shopping.jewellery.dto;

import com.shopping.jewellery.utils.OrderStatus;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class OrderDTO {
    private int orderId;
    private LocalDateTime date;
    private OrderStatus status;
    private int userId;
    private List<Integer> cartIds = new ArrayList<>();

    public OrderDTO() {
    }

    public OrderDTO(int orderId, LocalDateTime date, OrderStatus status, int userId, List<Integer> cartIds) {
        this.orderId = orderId;
        this.date = date;
        this.status = status;
        this.userId = userId;
        this.cartIds = cartIds;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public List<Integer> getCartIds() {
        return cartIds;
    }

    public void setCartIds(List<Integer> cartIds) {
        this.cartIds = cartIds;
    }
}
