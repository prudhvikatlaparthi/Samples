package com.pru.oldsignalr

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import microsoft.aspnet.signalr.client.Platform
import microsoft.aspnet.signalr.client.http.android.AndroidPlatformComponent
import microsoft.aspnet.signalr.client.hubs.HubConnection
import microsoft.aspnet.signalr.client.hubs.HubProxy
import microsoft.aspnet.signalr.client.transport.ClientTransport
import microsoft.aspnet.signalr.client.transport.ServerSentEventsTransport

class MainActivity : AppCompatActivity() {
    private lateinit var mHubConnection: HubConnection
    private lateinit var mHubProxy: HubProxy
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startSignalR()
    }

    private fun startSignalR() {
        Platform.loadPlatformComponent(AndroidPlatformComponent())

        mHubConnection = HubConnection(
            "https://machatapi.justbilling.co/"
        )
        mHubProxy = mHubConnection.createHubProxy("chatHub")
        val clientTransport: ClientTransport = ServerSentEventsTransport(mHubConnection.logger)
        val signalRFuture = mHubConnection.start(clientTransport)

        try {
            signalRFuture.get()
        } catch (e: InterruptedException) {
            Log.i("Prudhvi Log", "startSignalR: InterruptedException $e")
            Thread.currentThread().interrupt()
            return
        }

        mHubProxy.on<Unit>("TrackConnection") {
            Log.i("Prudhvi Log", "startSignalR: TrackConnection message")
            GlobalScope.launch {
                delay(2000)
                mHubProxy.invoke("CheckConnection")
            }
        }
        mHubProxy.invoke("CheckConnection")
    }
}