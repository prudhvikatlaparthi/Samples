package com.pru.navapp.fragments

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.NavigationUI
import androidx.navigation.ui.NavigationUI.setupActionBarWithNavController
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.pru.navapp.Listener
import com.pru.navapp.R
import com.pru.navapp.base.BaseFragment
import com.pru.navapp.databinding.FragmentMainBinding
import listeners.NavigationDrawListener

class MainFragment : BaseFragment(R.layout.fragment_main),NavigationDrawListener {
    private lateinit var binding: FragmentMainBinding
    private lateinit var navController: NavController
    private lateinit var navHostFragment: NavHostFragment
    private lateinit var appBarConfiguration: AppBarConfiguration
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentMainBinding.bind(view)
        navHostFragment =
            childFragmentManager.findFragmentById(R.id.nav_b_host_fragment) as NavHostFragment
        navController = navHostFragment.findNavController()
        setupToolBar(title = "Main")
        setViews()
        setEvents()
    }

    private fun getCurrentFragment(): Fragment {
        val frag = navHostFragment.childFragmentManager.fragments[0]
        Log.i("Prudhvi Log", "getCurrentFragment: $frag")
        return frag
    }

    override fun setViews() {
        setFragmentResultListener("KEY_RESULT") { _, bundle ->
            if (getCurrentFragment() is Listener) {
                (getCurrentFragment() as Listener).refreshView(bundle)
            }
        }
    }

    override fun setEvents() {
        binding.tvB1.setOnClickListener {
            navController.popBackStack()
            navController.navigate(R.id.b1Fragment)
        }
        binding.tvB2.setOnClickListener {
            navController.popBackStack()
            navController.navigate(R.id.b2Fragment)
        }
        binding.tvB3.setOnClickListener {
            navController.popBackStack()
            navController.navigate(R.id.b3Fragment)
        }
    }

}