package com.pru.navapp.bottom

import androidx.fragment.app.Fragment
import com.pru.navapp.R
import com.pru.navapp.base.BaseFragment


class B1Fragment : BaseFragment(R.layout.fragment_b1) {
    override fun setViews() {

    }

    override fun setEvents() {

    }

}