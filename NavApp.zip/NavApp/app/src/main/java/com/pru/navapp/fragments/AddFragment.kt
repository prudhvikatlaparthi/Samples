package com.pru.navapp.fragments

import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import com.pru.navapp.R
import com.pru.navapp.base.BaseFragment
import com.pru.navapp.databinding.FragmentAddBinding
import listeners.NavigationDrawListener


class AddFragment : BaseFragment(R.layout.fragment_add),NavigationDrawListener {
    private lateinit var binding: FragmentAddBinding
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentAddBinding.bind(view)
        setupToolBar()
        setViews()
        setEvents()
    }

    override fun setViews() {

    }

    override fun setEvents() {
        binding.btnSave.setOnClickListener {
            setFragmentResult(
                "KEY_RESULT",
                bundleOf("VALUE" to binding.edtName.text.toString())
            )
            findNavController().popBackStack()
        }
    }
}