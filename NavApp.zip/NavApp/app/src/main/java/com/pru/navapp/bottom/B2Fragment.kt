package com.pru.navapp.bottom

import android.os.Bundle
import android.view.View
import com.pru.navapp.Listener
import com.pru.navapp.R
import com.pru.navapp.base.BaseFragment
import com.pru.navapp.databinding.FragmentB2Binding
import com.pru.navapp.utils.Global.getMainActivity


class B2Fragment : BaseFragment(R.layout.fragment_b2), Listener {
    private lateinit var binding: FragmentB2Binding

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentB2Binding.bind(view)
        setEvents()
    }

    override fun setViews() {

    }

    override fun setEvents() {
        binding.fabAdd.setOnClickListener {
            getMainActivity().navigate(R.id.action_mainFragment_to_addFragment)
        }
    }


    override fun refreshView(any: Any?) {
        binding.tvValue.text = (any as Bundle).getString("VALUE")
    }
}