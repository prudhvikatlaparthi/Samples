package com.pru.navapp.bottom

import com.pru.navapp.R
import com.pru.navapp.base.BaseFragment


class B3Fragment : BaseFragment(R.layout.fragment_b3) {
    override fun setViews() {

    }

    override fun setEvents() {

    }

}