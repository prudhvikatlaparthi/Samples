package com.pru.navapp.base

import androidx.annotation.LayoutRes
import androidx.fragment.app.Fragment
import com.pru.navapp.fragments.AddFragment
import com.pru.navapp.fragments.MainFragment
import com.pru.navapp.utils.Global.getMainActivity
import listeners.NavigationDrawListener

abstract class BaseFragment(@LayoutRes layoutId: Int) : Fragment(layoutId) {
    abstract fun setViews()
    abstract fun setEvents()

    fun setupToolBar(title: String? = null, hideToolBar: Boolean = false) {
        if (hideToolBar) {
            getMainActivity().supportActionBar?.hide()
        } else {
            getMainActivity().supportActionBar?.show()
        }
        getMainActivity().supportActionBar?.title = title

        //
        if (this is NavigationDrawListener) {
            getMainActivity().unLockNavigationDrawer()
        } else {
            getMainActivity().lockNavigationDrawer()
        }
    }
}