package com.pru.navapp

interface Listener {
    fun refreshView(any: Any?)
}