package com.pru.navapp.utils

import androidx.fragment.app.Fragment
import com.pru.navapp.MainActivity

object Global {
    fun Fragment.getMainActivity(): MainActivity {
        return this.requireActivity() as MainActivity
    }
}