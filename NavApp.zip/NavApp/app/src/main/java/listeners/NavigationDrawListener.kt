package listeners

interface NavigationDrawListener {
}